# v1.0.4
## 05/09/2015

1. [](#improved)
    * Fix for bottom menu links

# v1.0.3
## 03/01/2015

1. [](#improved)
    * Switched to Grav's built-in `jQuery` assets

# v1.0.2
## 02/19/2015

2. [](#improved)
	* Added SimpleSearch capability
    * Implemented new `param_sep` variable from Grav 0.9.18

# v1.0.1
## 02/10/2015

1. [](#new)
    * ChangeLog started...
